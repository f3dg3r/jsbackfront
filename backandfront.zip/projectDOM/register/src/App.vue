<script>
import { ref } from "vue";

export default {
  setup() {
    const swap = ref(true);

    function changeInfo() {

      if (swap.value) {
        swap.value = false;
      }
      else {
        swap.value = true;
      }

    }
    return {
      swap,
      changeInfo,
    };
  },
};
</script>

<template>
  <section v-if="swap" class="register1">
    <div class="form-box">
      <div class="form-value">
        <form action="">
          <h2>Login</h2>
          <div class="inputbox">
            <input placeholder="Email" type="email"  /> 
          
          </div>
          <div class="inputbox">
            <input type="password" placeholder="Password" /> 
         
          </div>
          <div class="forget">
            <label for=""
              ><input type="checkbox" />Remember Me
              <a href="#">Forget Password</a></label
            >
          </div>
          <button>Log In</button>
          <div class="register">
            <p>
              Don't have a account? <a href="#" @click="changeInfo">Register</a>
            </p>
            <br />
          
          </div>
        </form>
      </div>
    </div>
  </section>
  <section v-else class="register2">
    <div class="form-box">
      <div class="form-value">
        <form action="">
          <br>
          <h2>Register</h2>
          <div class="inputbox">
            <input type="email" placeholder="Email" />
          
          </div>
          <div class="inputbox">
            <input type="password" placeholder="Password" />
         
          </div>
          <div class="inputbox">
            <input type="name" placeholder="Name" />
         
          </div>
          <button>Register</button>
          <div class="register">
            <p>
               have a account? <a href="#" @click="changeInfo">Login</a>
            </p>
            <br />
          
          </div>
        </form>
      </div>
    </div>
  </section>
</template>
<!-- <p>have a account <a href="#" @click="changeInfo">Log In</a></p> -->
<style>

* {
  margin: 0;
  padding: 0;
  font-family: "Roboto Mono", monospace;
  font-optical-sizing: auto;
  font-weight: 300;
  font-style: normal;
  background: rgb(231, 196, 196);

}
@import url('https://fonts.googleapis.com/css2?family=Roboto+Mono:ital,wght@0,300;1,300&display=swap');

.roboto-mono-uniquifier {
  font-family: "Roboto Mono", monospace;
  font-optical-sizing: auto;
  font-weight: 300;
  font-style: normal;
}
.register1 {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  width: 100%;
  color: black;
 
  
}
.register2 {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  width: 100%;
  color: black;
}

.form-box {
  position: relative;
  width: 400px;
  height: 450px;
  background: rgb(194, 181, 181);
  display: flex;
  justify-content: center;
  align-items: center;
  background: transparent;
  border: 3px solid rgba(2, 2, 2, 0.5);
}

h2 {
  font-size: 2em;
  text-align: center;
}

.inputbox {
  position: relative;
  margin: 30px 0;
  width: 310px;
  border-bottom: 2px black solid;
}

.inputbox label {
  position: absolute;
  top: 50%;
  left: 5px;
  transform: translateY(-50%);
  pointer-events: none;
  transition: 0.5s;
}

/* input:focus ~ label,
input:valid ~ label{
    top: -5px;
} */

.inputbox input {
  width: 100%;
  height: 50px;
  background: transparent;
  border: none;
  outline: none;
  font-size: 1em;
  padding: 0 35px 0 5px;
}

.forget {
  margin: -15px 0 15px;
  font-size: 0.9em;
  display: flex;
  justify-content: center;
}

.forget label input {
  margin-right: 3px;
}

.forget label a {
  text-decoration: none;
}
.forget label a:hover {
  text-decoration: underline;
}

button {
  width: 100%;
  height: 40px;
  border-radius: 40px;
  border: none;
  outline: none;
  cursor: pointer;
  font-size: 1em;
  font-weight: 600;
  background-color: rgb(206, 181, 159);
}

.register {
  font-size: 0.9em;
  text-align: center;
  margin: 25px 0 10px;
}
.register p a {
  font-weight: 600;
  text-decoration: none;
}

.register p a:hover {
  text-decoration: underline;
}
</style>
