// const app = require('./app')

// const port = process.env.PORT||5000

// app.listen(port ,function(){
//     console.log(`Server has been started on ${port} port`)
// })
// app.listen(port, "127.0.0.1", function(){
//     console.log("Server start http://localhost:%s", port);
//     });


const app =require('./app')
const port= process.env.PORT||8000

app.listen(port, (err) => { 
    if (err) { 
        return (err) 
    } 
    console.log(`Server has been started on ${port} port`) 
});