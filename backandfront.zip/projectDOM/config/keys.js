module.exports = { 
    mongoURI: 'mongodb://0.0.0.0:27017/table' ,
    jwt:'dev-jwt'
}