//отвечает за регистрацию и вход

// const { router } = require('../app');

// routher.get('/login', (req,res)=>{
//     res.status(200).json({
//         login:true
//     })
// })

const express = require('express');
const controllers=require('../controllers/auth');
const router  = express.Router();

router.get('/login',controllers.login)
router.get('/register',controllers.register)

module.exports=router